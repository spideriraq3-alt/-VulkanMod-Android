# Build the VulkanMod test JAR

This ZIP is a source-code experiment, not an installable mod. The LWJGL Java binding version was changed to 3.3.6 to test the version mismatch seen in the supplied Zalith log. It has NOT been verified on an Android device, and it does not add Android native libraries.

## Build with GitHub Actions
1. Create a new repository on GitHub and upload the contents of this ZIP (not the ZIP file itself).
2. Open the repository's **Actions** tab.
3. Select **Build VulkanMod test** and press **Run workflow**. Alternatively, push a commit to `main`.
4. Wait for the workflow to finish. If it succeeds, open the run and download the `VulkanMod-build` artifact.
5. Extract the artifact and inspect the JAR name. Do not install it over the original mod until the build succeeds and you have a backup.

## Important Android limitation
A successful Java build does not prove Android support. LWJGL's Android native bindings and the shader compiler native libraries must be compatible with the exact Zalith runtime. This experiment only tests Java binding alignment; test on a copied profile and keep the original JAR backed up.
