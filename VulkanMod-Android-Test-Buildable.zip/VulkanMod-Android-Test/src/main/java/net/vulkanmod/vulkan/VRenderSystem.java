package net.vulkanmod.vulkan;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.platform.Window;

import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.fog.FogData;
import net.vulkanmod.render.engine.VkGpuBuffer;
import net.vulkanmod.vulkan.device.DeviceManager;
import net.vulkanmod.vulkan.shader.PipelineState;
import net.vulkanmod.vulkan.util.ColorUtil;
import net.vulkanmod.vulkan.util.MappedBuffer;
import net.vulkanmod.vulkan.util.VUtil;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;

import static com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread;
import static org.lwjgl.vulkan.VK10.*;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;

public abstract class VRenderSystem {
    private static final float DEFAULT_DEPTH_VALUE = 1.0f;

    private static long window;

    public static boolean depthTest = true;
    public static boolean depthMask = true;
    public static int depthFun = VK_COMPARE_OP_LESS_OR_EQUAL;
    public static int topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    public static int polygonMode = VK_POLYGON_MODE_FILL;
    public static boolean canSetLineWidth = false;

    public static int colorMask = PipelineState.ColorMask.getColorMask(true, true, true, true);

    public static int frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    public static int cullMode = VK_CULL_MODE_BACK_BIT;

    public static boolean logicOp = false;
    public static int logicOpFun = 0;

    private static final GpuTextureView[] shaderTextures = new GpuTextureView[12];

    public static float clearDepthValue = DEFAULT_DEPTH_VALUE;
    public static FloatBuffer clearColor = MemoryUtil.memCallocFloat(4);

    public static MappedBuffer modelViewMatrix = new MappedBuffer(16 * 4);
    public static MappedBuffer projectionMatrix = new MappedBuffer(16 * 4);
    public static MappedBuffer TextureMatrix = new MappedBuffer(16 * 4);
    public static MappedBuffer MVP = new MappedBuffer(16 * 4);

    public static MappedBuffer modelOffset = new MappedBuffer(3 * 4);
    public static MappedBuffer lightDirection0 = new MappedBuffer(3 * 4);
    public static MappedBuffer lightDirection1 = new MappedBuffer(3 * 4);

    public static MappedBuffer shaderColor = new MappedBuffer(4 * 4);
    public static MappedBuffer shaderFogColor = new MappedBuffer(4 * 4);
    public static FogData fogData;

    public static MappedBuffer screenSize = new MappedBuffer(2 * 4);
    public static MappedBuffer textureSize = new MappedBuffer(2 * 4);
    public static MappedBuffer texelSize = new MappedBuffer(2 * 4);

    public static float alphaCutout = 0.0f;

    private static boolean depthBiasEnabled = false;
    private static float depthBiasConstant = 0.0f;
    private static float depthBiasSlope = 0.0f;

    private static int currentTime;

    public static void initRenderer() {
        Vulkan.initVulkan(window);

        setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static void setShaderTexture(int i, @Nullable GpuTextureView gpuTextureView) {
        assertOnRenderThread();
        if (i >= 0 && i < shaderTextures.length) {
            shaderTextures[i] = gpuTextureView;
        }
    }

    @Nullable
    public static GpuTextureView getShaderTexture(int i) {
        assertOnRenderThread();
        return i >= 0 && i < shaderTextures.length ? shaderTextures[i] : null;
    }

    public static MappedBuffer getScreenSize() {
        updateScreenSize();
        return screenSize;
    }

    public static void updateScreenSize() {
        Window window = Minecraft.getInstance().getWindow();

        screenSize.putFloat(0, (float) window.getWidth());
        screenSize.putFloat(4, (float) window.getHeight());
    }

    public static MappedBuffer getTextureSize() {
        return textureSize;
    }

    public static MappedBuffer getTexelSize() {
        return texelSize;
    }

    public static void setTextureSize(int width, int height) {
        textureSize.putInt(0, width);
        textureSize.putInt(4, height);

        texelSize.putFloat(0, 1.0f / width);
        texelSize.putFloat(4, 1.0f / height);
    }

    public static void setWindow(long window) {
        VRenderSystem.window = window;
    }

    public static ByteBuffer getModelOffset() {
        return modelOffset.buffer;
    }

    public static int maxSupportedTextureSize() {
        return DeviceManager.deviceProperties().limits().maxImageDimension2D();
    }

    public static void applyMVP(Matrix4f MV, Matrix4f P) {
        applyModelViewMatrix(MV);
        applyProjectionMatrix(P);
        calculateMVP();
    }

    public static void applyModelViewMatrix(Matrix4f mat) {
        mat.get(modelViewMatrix.buffer.asFloatBuffer());
    }

    public static void applyProjectionMatrix(Matrix4f mat) {
        mat.get(projectionMatrix.buffer.asFloatBuffer());
    }

    public static void applyProjectionMatrix(GpuBufferSlice bufferSlice) {
        long ptr = ((VkGpuBuffer) bufferSlice.buffer()).getBuffer().getDataPtr();
        ByteBuffer byteBuffer = MemoryUtil.memByteBuffer(ptr + bufferSlice.offset(), (int) bufferSlice.length());
        Matrix4f matrix4f = new Matrix4f().set(byteBuffer);

        matrix4f.get(projectionMatrix.buffer.asFloatBuffer());
    }

    public static void calculateMVP() {
        org.joml.Matrix4f MV = new org.joml.Matrix4f(modelViewMatrix.buffer.asFloatBuffer());
        org.joml.Matrix4f P = new org.joml.Matrix4f(projectionMatrix.buffer.asFloatBuffer());

        P.mul(MV).get(MVP.buffer);
    }

    public static void setTextureMatrix(Matrix4f mat) {
        mat.get(TextureMatrix.buffer.asFloatBuffer());
    }

    public static MappedBuffer getTextureMatrix() {
        return TextureMatrix;
    }

    public static MappedBuffer getModelViewMatrix() {
        return modelViewMatrix;
    }

    public static MappedBuffer getProjectionMatrix() {
        return projectionMatrix;
    }

    public static MappedBuffer getMVP() {
        return MVP;
    }

    public static void setModelOffset(float x, float y, float z) {
        long ptr = modelOffset.ptr;
        VUtil.UNSAFE.putFloat(ptr, x);
        VUtil.UNSAFE.putFloat(ptr + 4, y);
        VUtil.UNSAFE.putFloat(ptr + 8, z);
    }

    public static void setShaderColor(float f1, float f2, float f3, float f4) {
        ColorUtil.setRGBA_Buffer(shaderColor, f1, f2, f3, f4);
    }

    public static void setShaderFogColor(float f1, float f2, float f3, float f4) {
        ColorUtil.setRGBA_Buffer(shaderFogColor, f1, f2, f3, f4);
    }

    public static MappedBuffer getShaderColor() {
        return shaderColor;
    }

    public static MappedBuffer getShaderFogColor() {
        return shaderFogColor;
    }

    public static FogData getFogData() {
        return fogData;
    }

    public static void setCurrentTime(int currentTime) {
        VRenderSystem.currentTime = currentTime;
    }

    public static int getCurrentTime() {
        return currentTime;
    }

    public static void setClearColor(float f1, float f2, float f3, float f4) {
        ColorUtil.setRGBA_Buffer(clearColor, f1, f2, f3, f4);
    }

    public static void clear(int mask) {
        Renderer.clearAttachments(mask);
    }

    public static void clearDepth(double depth) {
        clearDepthValue = (float) depth;
    }

    // Pipeline state

    public static void disableDepthTest() {
        depthTest = false;
    }

    public static void depthMask(boolean b) {
        depthMask = b;
    }

    public static void setPrimitiveTopology(int mode) {
        VRenderSystem.topology = mode;
    }

    public static void setPolygonMode(int mode) {
        VRenderSystem.polygonMode = mode;
    }

    public static void setPrimitiveTopologyGL(final int mode) {
        VRenderSystem.topology = switch (mode) {
            case GL11.GL_LINES, GL11.GL_LINE_STRIP  -> VK_PRIMITIVE_TOPOLOGY_LINE_LIST;
            case GL11.GL_TRIANGLE_FAN, GL11.GL_TRIANGLES, GL11.GL_TRIANGLE_STRIP -> VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
            case GL11.GL_POINTS -> VK_PRIMITIVE_TOPOLOGY_POINT_LIST;
            default -> throw new RuntimeException(String.format("Unknown GL primitive topology: %s", mode));
        };
    }

    public static void setPolygonModeGL(final int mode) {
        VRenderSystem.polygonMode = switch (mode) {
            case GL11.GL_POINT -> VK_POLYGON_MODE_POINT;
            case GL11.GL_LINE -> VK_POLYGON_MODE_LINE;
            case GL11.GL_FILL -> VK_POLYGON_MODE_FILL;
            default -> throw new RuntimeException(String.format("Unknown GL polygon mode: %s", mode));
        };
    }

    public static void setLineWidth(final float width) {
        if (canSetLineWidth) {
            Renderer.setLineWidth(width);
        }
    }

    public static void colorMask(boolean b, boolean b1, boolean b2, boolean b3) {
        colorMask = PipelineState.ColorMask.getColorMask(b, b1, b2, b3);
    }

    public static int getColorMask() {
        return colorMask;
    }

    public static void enableDepthTest() {
        depthTest = true;
    }

    public static void enableCull() {
        cullMode = VK_CULL_MODE_BACK_BIT;
    }

    public static void disableCull() {
        cullMode = VK_CULL_MODE_NONE;
    }

    public static void setDepthFun(int depthFun) {
        VRenderSystem.depthFun = depthFun;
    }

    public static void glDepthFun(int depthFun) {
        int vkDepthFun = PipelineState.DepthState.glToVulkan(depthFun);
        setDepthFun(vkDepthFun);
    }

    public static void enableBlend() {
        PipelineState.blendInfo.enabled = true;
    }

    public static void disableBlend() {
        PipelineState.blendInfo.enabled = false;
    }

    public static void blendFunc(int srcFactor, int dstFactor) {
        PipelineState.blendInfo.setBlendFunction(srcFactor, dstFactor);
    }

    public static void blendFuncSeparate(int srcFactorColor, int dstFactorColor, int srcFactorAlpha, int dstFactorAlpha) {
        PipelineState.blendInfo.setBlendFuncSeparate(srcFactorColor, dstFactorColor, srcFactorAlpha, dstFactorAlpha);
    }

    public static void blendOp(int op) {
        PipelineState.blendInfo.setBlendOp(op);
    }

    public static void glBlendFunc(int srcFactor, int dstFactor) {
        int vkSrcFactor = PipelineState.BlendInfo.glToVulkanBlendFactor(srcFactor);
        int vkDstFactor = PipelineState.BlendInfo.glToVulkanBlendFactor(dstFactor);
        PipelineState.blendInfo.setBlendFunction(vkSrcFactor, vkDstFactor);
    }

    public static void glBlendFuncSeparate(int srcFactorColor, int dstFactorColor, int srcFactorAlpha, int dstFactorAlpha) {
        int vkColorSrcFactor = PipelineState.BlendInfo.glToVulkanBlendFactor(srcFactorColor);
        int vkColorDstFactor = PipelineState.BlendInfo.glToVulkanBlendFactor(dstFactorColor);
        int vkAlphaSrcFactor = PipelineState.BlendInfo.glToVulkanBlendFactor(srcFactorAlpha);
        int vkAlphaDstFactor = PipelineState.BlendInfo.glToVulkanBlendFactor(dstFactorAlpha);
        PipelineState.blendInfo.setBlendFuncSeparate(vkColorSrcFactor, vkColorDstFactor, vkAlphaSrcFactor, vkAlphaDstFactor);
    }

    public static void glBlendOp(int op) {
        int vkBlendOp = PipelineState.BlendInfo.glToVulkanBlendOp(op);
        PipelineState.blendInfo.setBlendOp(vkBlendOp);
    }

    public static void enableColorLogicOp() {
        logicOp = true;
    }

    public static void disableColorLogicOp() {
        logicOp = false;
    }

    public static void setLogicOpFun(int logicOpFun) {
        VRenderSystem.logicOpFun = logicOpFun;
    }

    public static void glLogicOp(int glLogicOp) {
        setLogicOpFun(PipelineState.LogicOpState.glToVulkan(glLogicOp));
    }

    public static void polygonOffset(float slope, float biasConstant) {
        if (depthBiasConstant != biasConstant || depthBiasSlope != slope) {
            depthBiasConstant = biasConstant;
            depthBiasSlope = slope;

            Renderer.setDepthBias(depthBiasConstant, depthBiasSlope);
        }
    }

    public static void enablePolygonOffset() {
        if (!depthBiasEnabled) {
            Renderer.setDepthBias(depthBiasConstant, depthBiasSlope);
            depthBiasEnabled = true;
        }
    }

    public static void disablePolygonOffset() {
        if (depthBiasEnabled) {
            Renderer.setDepthBias(0.0F, 0.0F);
            depthBiasEnabled = false;
        }
    }

}
